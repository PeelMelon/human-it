/*
 * 범위 주석
 * 작성자 : 킹용권
 * 작성일 : 2025.12.31
 */
public class Hello {
    // 프로그램 실행 진입점
    public static void main(String[] args) {
        //콘솔에 출력하는 실행문
        System.out.println("hello, Java222");
        /*
        int x;                           //변수 xtjsdjs
        x = 1;                           //변수 x에 1을 저장
        int y = 2;                       // 변수 y를 선언하고 2를 저장
        int result = x + y;              //변수 result를 선언하고 변수 x와 y를 더한 값을 저장
        System.out.println(result);      //println 메소드 호출
*/
        int x = 1; int y = 2;
        int result =
        x + y;
    } //end of main method
}



//end if class 
//야바야바코바코바