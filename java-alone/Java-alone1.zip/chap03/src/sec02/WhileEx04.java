package sec02;

public class WhileEx04 {

	public static void main(String[] args) {
		// 문제 3 풀이
		/*
		int n1 = (Math.random()* 6) + 1;
		int n2 = (Math.random()* 6) + 1;
		
		System.out.println("("+ n1 ", " _+n2 +")");
		int a = 6;
		int b = 6;*/
	
	}
	
	//for(int x =1; x < 11; x++) {
		//for(int y= 1; y<11; y++) {
			//if((4 * x + 5 * y)== 60)
		}

	


