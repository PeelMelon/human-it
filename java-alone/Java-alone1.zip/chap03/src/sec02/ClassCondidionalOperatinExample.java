package sec02;

public class ClassCondidionalOperatinExample {

}
