package sec02;

import java.util.Scanner;

public class exam10 {
 //9번 문제
	public static void main(String[] args) {
		
		
		/* Scanner scanner = new Scanner(System.in);
		
		System.out.println();
		double num1 Double.parseDouble(scanner.nextLine());
		
		System.out.println();
		double num2 Double.parseDouble(scanner.nextLine());
		
		System.out.println("-----------------");
		if num2 != 0.0){
			System.out.println("결과:" + (num1 + num2));
		}else {System.out.println("결과: 무한대");*/
		
		//11문제
		// x > 7 > true y <= 5 true ture && -> true
		
	
	  }
   }
 



