package sec02;

public class chapex05 {

	public static void main(String[] args) {
		// 문제 4
		int max = 0;
		int[] array = {1, 5, 3, 8, 2};

		for (int i = 0; i < array.length; i++) {
			if (array[i] > max) {
				max = array[i]; // 더 큰 값을 max에 저장
		    }
		}

		System.out.println(max); // 최대값 출력
		
	 // 문제 5
		//int[][] array = {
				//{95,86}, {83, 92, 96}, {78, 83, 93, 97, 88}
		//};
		//int sum= 0;
		//double avg = 0.0;
		
	  //for(int i=0; i <array.length; i++) {
		 // int temp1 = array[i].length;
		  
		 // for(int j = 0; j < temp1; j++) {
			//  sum = sum + array[i][j];
			  }
		 // count = 1;
	  
		
	}	
	



