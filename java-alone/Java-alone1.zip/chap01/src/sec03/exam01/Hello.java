package sec03.exam01;

public class Hello {

	public static void main(String[] args) {
		System.out.println("Hello, Java");
		
		int x = 1; int y = 2;
        int result = x + y;
        System.out.println(result);
	}
}
