package sec03.exam02;

public class RunStatementExample {

	public static void main(String[] args) {
		int x = 1; 	         // 변수 x 선언 1저장
		int y = 2; 	         // 변수 y 선언 2저장
		int result = x + y;  // x + y
		
		System.out.println(result);  //모니터에 출력하는 메소드 호출
	}

}
