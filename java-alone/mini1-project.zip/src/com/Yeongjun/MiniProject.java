package com.Yeongjun;

import java.io.*;
import java.util.*;
import java.text.*;

public class MiniProject {

	public static void main(String[] args) {
		
	}

}
