package Practice03;

public class Student {
	
	public int StudentNum;
	public String name;
	
	public Student (int StudentNum, String name) {
		this.StudentNum = StudentNum;
		this.name = name;
	}

}
