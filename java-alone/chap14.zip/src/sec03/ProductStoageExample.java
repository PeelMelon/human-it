package sec03;

//	상품관리 실행 클래스
public class ProductStoageExample {

	public static void main(String[] args) {
		(new ProductStoage()).showMenu();

	}

}
